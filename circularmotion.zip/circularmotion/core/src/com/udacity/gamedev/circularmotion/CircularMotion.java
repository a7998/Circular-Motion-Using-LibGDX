com.udacity.gamedev.circularmotion.CircularMotion

import com.Badlogic.Gdx.g2d.Spritebatch;
import com.badlogic.Gdx.utils.Viewport;
import com.badlogic.Gdx.ShapeRenderer;


public class CircularMotion extends ApplicationAdapter
{
 FitViewport ftp;
 ShapeRenderer rtm;
 Vector2 pos;
 Vector2 vel;
private long initialtime;


@Override
public void create()
{
  ftp=new FitViewport(constants.WORLD_SIZE,contants.WORLD_SIZE);
   rtm=new ShapeRenderer();

 

}
@Override
public void update(int width,height)
{
 ftp.update(width,height);
}
@Override
public void render()
{
 ftp.apply();

  Gdx.gl.glClearColor(0, 0, 0, 1);
  Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); 
 rtm.setProjectionMatrix(ftp.Combined());

float elapsedtime=TimeUtils.nano()-initialTime;
 float elapsedperiods=elapsedtime/constants.PERIODS;
 float cycleposition=elapsedperiods % 1;
float x = constants.WORLD_SIZE / 2 + constants.MOVEMENT_RADIUS * MathUtils.cos(MathUtils.PI2 * cyclePosition);
float y = constants.WORLD_SIZE / 2 + constants.MOVEMENT_RADIUS * MathUtils.sin(MathUtils.PI2 * cyclePosition);
rtm.begin(ShapeType.Filled);
rtm.circle(x,y,constants.RADIUS);
rtm.end();

  
 

}