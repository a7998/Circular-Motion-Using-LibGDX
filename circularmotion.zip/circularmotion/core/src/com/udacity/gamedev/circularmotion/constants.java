import com.udacity.gamedev.circularmotion.constants


public class constants 
{
 public static final float WORLD_SIZE=940.0f;
 public static final float PERIODS=2.0f;
public static final float WORLD_SIZE=940.0f;
public static final float MOVEMENT_RADIUS=90.0f;

}