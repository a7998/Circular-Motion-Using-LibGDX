# Movement!

So far we've been drawing static images, but in a game, we want things to be flying all over the place! To make things move, we need to know how to keep track of time. We'll also learn more about LibGDX game architecture, and how we can set up a game that has multiple screens. 

Finally, we'll learn to fake some very basic physics, so we can make objects move in a realistic way.

Check out the TODOs


